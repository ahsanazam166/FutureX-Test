package com.work.jsonEquivalence;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonEquivalenceApplicationTests {

	@Test
	void contextLoads() {
	}

}
