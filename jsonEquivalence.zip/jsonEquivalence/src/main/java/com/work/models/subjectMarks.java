package com.work.models;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@Data
@JsonPropertyOrder({ "mathematics", "english"})
public class subjectMarks {
    int mathematics;
    int english;
}