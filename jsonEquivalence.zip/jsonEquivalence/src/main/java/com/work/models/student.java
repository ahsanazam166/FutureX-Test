package com.work.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.Data;

@Data
@JsonPropertyOrder({ "rollNo", "name", "className"})
public class student {

    int rollNo;
    String name;
    String className;
    List<subjectMarks> result;

}
