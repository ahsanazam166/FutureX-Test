package com.work.resources;

import java.io.File;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.work.models.student;

public class jsonComparison {
    public void compareJson() throws Exception {
        final ObjectMapper objectMapper = new ObjectMapper();
        student wrapper = objectMapper.readValue(new File("src/main/java/com/work/resources/expected.json"), student.class);
        student wrapper2 = objectMapper.readValue(new File("src/main/java/com/work/resources/real.json"), student.class);
        if(wrapper.equals(wrapper2)){
            System.out.println("JSON files are equal");
        } else {
            System.out.println("JSON files are not equal");
        }

    }

}



