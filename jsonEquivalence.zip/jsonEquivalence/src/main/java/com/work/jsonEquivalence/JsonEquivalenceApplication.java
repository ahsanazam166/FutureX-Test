package com.work.jsonEquivalence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.work.resources.jsonComparison;

@SpringBootApplication
public class JsonEquivalenceApplication {

	public static void main(String[] args) {
		SpringApplication.run(JsonEquivalenceApplication.class, args);
		jsonComparison compareJsonFiles = new jsonComparison();
		try {
			compareJsonFiles.compareJson();
		}
		catch(Exception ex){
			System.out.println("False: JSON files are not equal");
		}
	}

}
