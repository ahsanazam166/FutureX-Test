package com.test.futurex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FuturexApplicationTests {

	@Test
	void contextLoads() {
	}

}
