package com.test.resources;

import java.io.IOException;
import java.util.List;

import org.apache.commons.csv.CSVRecord;

public class CsvComparer {
    public boolean compare() throws IOException {

        String path1 = "/home/teresol/Desktop/csvtest/futurex/src/main/java/com/test/resources/Book1.csv";
        String path2 = "/home/teresol/Desktop/csvtest/futurex/src/main/java/com/test/resources/Book2.csv";

        List<CSVRecord> records1 = CsvReader.read(path1);
        List<CSVRecord> records2 = CsvReader.read(path2);

        if (records1.size() != records2.size()) {
            return false;
        }

        for (int i = 0; i < records1.size(); i++) {
            CSVRecord record1 = records1.get(i);
            CSVRecord record2 = records2.get(i);

            if (!record1.equals(record2)) {
                return false;
            }
        }

        return true;
    }
}
