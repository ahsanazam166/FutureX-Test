package com.test.resources;

import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

public class CsvReader {
    public static List<CSVRecord> read(String path) throws IOException {
        FileReader fileReader = new FileReader(path);
        CSVParser csvParser = new CSVParser(fileReader, CSVFormat.DEFAULT.withFirstRecordAsHeader());
        List<CSVRecord> records = csvParser.getRecords();
        csvParser.close();
        return records;
    }
}
