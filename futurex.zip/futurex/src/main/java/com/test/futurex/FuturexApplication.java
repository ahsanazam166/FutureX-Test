package com.test.futurex;

import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.test.resources.CsvComparer;

@SpringBootApplication
public class FuturexApplication {

	public static void main(String[] args) throws IOException {
		SpringApplication.run(FuturexApplication.class, args);
		CsvComparer csvComparer = new CsvComparer();
        if(csvComparer.compare()){
			System.out.println("true");
		}else{
			System.out.println("false");
		}
	}

}
